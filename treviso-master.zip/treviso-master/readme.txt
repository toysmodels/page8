﻿== ABOUT TEMPLATE == 

Theme Name : Treviso
Version    : 1.0.0
Theme URL  : http://moozthemes.com/treviso-clean-portfolio-bootstrap-theme/

Author: MOOZ Themes
Author URL: http://moozthemes.com/

License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl.html

== COPYRIGHT AND LICENSE == 

Treviso Bootstrap Template, Copyright 2016 MOOZ Themes
Treviso is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Treviso Bootstrap Template bundles the following third-party resources:

* FontAwesome.
  FontAwesome 4.2.0
  Copyright 2012 Dave Gandy
  Font License: SIL OFL 1.1
  Code License: MIT License
  http://fontawesome.io/license/
* Bootstrap by twitter.
  Bootstrap is Licensed under the MIT License. https://github.com/twbs/bootstrap/blob/master/LICENSE.
* Other custom js files are our own creation and is licensed under the same license as this theme. 

All other resources and theme elements are licensed under the [GNU GPL](http://www.gnu.org/licenses/gpl.html), version 3 or later.

==== THEME CHANGELOG ====

coming soon